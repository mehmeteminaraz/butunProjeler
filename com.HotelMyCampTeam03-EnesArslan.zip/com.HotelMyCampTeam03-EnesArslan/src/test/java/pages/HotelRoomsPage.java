package pages;

public class HotelRoomsPage {
}
