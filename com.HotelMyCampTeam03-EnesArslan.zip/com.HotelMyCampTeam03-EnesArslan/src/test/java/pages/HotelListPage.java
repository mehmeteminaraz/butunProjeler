package pages;

public class HotelListPage {
}
