package pages;

public class HotelReservationPage {
}
