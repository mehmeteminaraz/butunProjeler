package pages;

public class RoomReservationsPage {

}
